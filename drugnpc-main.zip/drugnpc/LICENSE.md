╔════════════════════════════════════════════╗

║      LiveNZ Script License (v1.0 - 2026)  ║

╠════════════════════════════════════════════╣

║ Copyright (c) 2026 tzntzntntnt            ║

║ All rights reserved.                      ║

╠════════════════════════════════════════════╣

║ USAGE TERMS:                               ║

║ 1. You may use this script on your FiveM  ║

║    server for personal or commercial use. ║

║ 2. You may modify it for personal use     ║

║    ONLY.                                   ║

║ 3. Redistribution, resale, or sharing     ║

║    without permission is strictly         ║

║    prohibited.                             ║

║ 4. Copyright notices and license must not ║

║    be removed.                             ║

╠════════════════════════════════════════════╣

║ SUPPORT \& CONTACT:                         ║

║ Email: tzntzntntnt@gmail.com              ║

║ Discord: Coming soon                       ║

╚════════════════════════════════════════════╝



